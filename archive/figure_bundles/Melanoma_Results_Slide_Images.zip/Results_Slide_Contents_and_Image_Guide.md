# Results section: four slides, three minutes

These drafts use verified results from the uploaded completed Attention U-Net
notebook. Add the other team pipelines only after checking that their training,
validation and test splits match. No teammate results are supplied in this pack.

## Slide 1: Testing and pipeline comparison (60 seconds)

- Dataset: ISIC 2016 Task 3B dermoscopic images.
- Development split: 720 training images and 180 validation images.
- Test set: 379 images, including 75 melanoma and 304 benign images.
- Validation data determine the saved checkpoints and classification threshold.

| Pipeline | Dice | IoU | Accuracy | Sensitivity | Specificity | ROC-AUC |
|---|---:|---:|---:|---:|---:|---:|
| Attention U-Net + EfficientNetB0 | 0.8930 | 0.8228 | 64.12% | 84.00% | 59.21% | 0.8101 |

Footnote: The official test set was previously inspected. Results are exploratory.

Image/layout: Use the editable comparison table. Add one row for each teammate's
verified pipeline. Dice and IoU assess segmentation. The other columns assess
melanoma classification. Keep the test loss formula consistent for loss comparisons.

## Slide 2: Lesion segmentation results (45 seconds)

- Mean Dice: 0.8930.
- Mean IoU: 0.8228.
- Segmentation test loss: 0.2808 (BCE + soft Dice loss).
- Median example: Dice 0.9297. Worst example: Dice approximately 0.0000.

Takeaway: Most masks overlap the expert lesion boundary well, while the worst
example has an empty predicted mask.

Image: Slide2_Segmentation_Examples.png, extracted unchanged from the notebook.
For a readable slide, show the median and worst rows and focus on Original,
Expert mask and Predicted mask columns. The original complete figure also includes
overlays and ROIs. Best example: ISIC_0000231, Dice 0.9876. Median: ISIC_0011213,
Dice 0.9297. Worst: ISIC_0000040, Dice approximately 0.0000.

Explain that an empty mask triggers the full-image ROI fallback. The fallback
allows classification to continue but does not correct the failed segmentation.

## Slide 3: Melanoma classification results (45 seconds)

| Metric | Result |
|---|---:|
| Accuracy | 64.12% |
| Sensitivity | 84.00% |
| Specificity | 59.21% |
| ROC-AUC | 0.8101 |

- Detected 63 of 75 melanoma images, with 12 missed.
- Correctly identified 180 of 304 benign images, with 124 false positives.
- False positives remain a major classification limitation.

Image: Slide3_Confusion_Matrix.png, redrawn from the notebook's recorded counts.
Rows show actual labels. Columns show predicted labels. TN=180, FP=124, FN=12,
TP=63. Position the matrix beside the four metrics.

Backup information: precision 33.69%, F1 0.4809, balanced accuracy 71.61%,
classification loss 0.4888 (unweighted BCE). Pixel specificity 96.71% measures
background segmentation and must not replace classification specificity 59.21%.

## Slide 4: Software prototype and verification (30 seconds)

- Gradio prototype loads the saved segmentation and classification models.
- Upload a dermoscopic image to obtain the model prediction, lesion mask and ROI.
- Grad-CAM visualises regions contributing to the prediction.
- App scores and masks matched the notebook in three checked cases.

Footnote: Student research prototype. Clinical validation remains future work.

Image: Capture your actual Gradio application after analysing a real ISIC image.
Show the upload, prediction and model outputs. A genuine interface screenshot is
not embedded in the submitted notebook, which stores an iframe link instead.
Do not substitute a fabricated interface for evidence of the working app.
Backup_Classification_Examples_and_GradCAM.png supplies real model output examples.

The verification cases were the first, middle and nearest-threshold test images.
This is a software consistency check, not a user study or comprehensive validation.
Do not claim a measured app runtime: the recorded 52.98 seconds covers batched
segmentation evaluation of the test set, excluding the complete app workflow.

## Backup figures

- Backup_Confusion_Matrix_and_ROC.png: original confusion matrix and ROC curve.
- Backup_Test_Dice_Distribution.png: variability across test images.
- Backup_Historical_Segmentation_Curves.png: rounded historical console summaries.
- Backup_Historical_Classifier_Head_Curves.png: frozen-head training summaries.
- Backup_Historical_Classifier_Finetuning_Curves.png: fine-tuning summaries.

Historical plots describe earlier training. The reporting run reused the frozen
models. No new training history or uncertainty intervals are fabricated here.
